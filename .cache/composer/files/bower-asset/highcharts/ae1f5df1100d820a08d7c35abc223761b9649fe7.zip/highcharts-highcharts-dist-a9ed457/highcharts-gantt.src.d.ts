/*!*
 *
 *  Copyright (c) Highsoft AS. All rights reserved.
 *
 *!*/
import * as Highcharts from './highcharts.src';
import GanttModule from './modules/gantt.src';
export = Highcharts;
