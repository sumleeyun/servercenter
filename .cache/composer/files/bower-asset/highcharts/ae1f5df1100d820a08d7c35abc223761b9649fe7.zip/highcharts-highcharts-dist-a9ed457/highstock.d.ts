/*!*
 *
 *  Copyright (c) Highsoft AS. All rights reserved.
 *
 *!*/
import * as Highcharts from './highcharts';
import StockModule from './modules/stock';
export = Highcharts;
