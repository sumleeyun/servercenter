/*!*
 *
 *  Copyright (c) Highsoft AS. All rights reserved.
 *
 *!*/
import * as Highcharts from './highcharts.src';
import StockModule from './modules/stock.src';
export = Highcharts;
