/*!*
 *
 *  Copyright (c) Highsoft AS. All rights reserved.
 *
 *!*/
import * as Highcharts from './highcharts';
import GanttModule from './modules/gantt';
export = Highcharts;
