/*!*
 *
 *  Copyright (c) Highsoft AS. All rights reserved.
 *
 *!*/
import * as Highcharts from './highcharts.src';
import MapModule from './modules/map.src';
export = Highcharts;
